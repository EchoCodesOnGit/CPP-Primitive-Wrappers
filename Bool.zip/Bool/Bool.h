//
// Created by ebane on 1/3/2025.
//

#ifndef WRAPPERS_BOOL_H
#define WRAPPERS_BOOL_H
#include "../functionality/class_necessities.h"
class Bool{
private:
    std::unique_ptr<bool> currState;
public:
    /*FIELDS*/
    static constexpr bool FALSE = false;
    static constexpr bool TRUE = true;
    /*END FIELDS*/
    /*CONSTRUCTORS*/
    Bool(bool b) : currState(std::make_unique<bool>(b)){}
    Bool(std::string sBool){
        std::transform(sBool.begin(), sBool.end(),sBool.begin(),::toupper);
        if(sBool == "TRUE"){
            *this->currState = true;
        }
        else if(sBool == "FALSE"){
            *this->currState = false;
        }
        else{
            throw std::invalid_argument("Invalid value for Bool object");
        }
    }
    /*END CONSTRUCTORS*/
    /*METHODS*/
    bool boolValue(){
        return *this->currState;
    }
    static int compare(bool x, bool y){
        return x > y ? 1 : x < y ? -1 : 0;
    }
    int compareTo(Bool* otherBool){
        return *this->currState > *otherBool->currState ? 1 : *this->currState < *otherBool->currState ? -1 : 0;
    }
    bool equals(Bool* otherBool){
        return (*this->currState == *otherBool->currState) || (this == otherBool);
    }
    static bool getBool(const std::string& name){
        const char* value = std::getenv(name.c_str());
        if(value != nullptr){
            return (std::string(value) == "true");
        }
        return false;
    }
    size_t hashCode(){
       return *this->currState ? 1231 : 1237;
    }
    static size_t hashCode(bool value){
        return std::hash<bool>{}(value);
    }
    static bool logicalAnd(bool a, bool b){
        return a && b;
    }
    static bool logicalOr(bool a, bool b){
        return a || b;
    }
    static bool logicalXor(bool a, bool b){
        return (a || b) && !(a && b);
    }
    static bool parseBool(const std::string& s){
        std::string newStr(s);
        std::transform(newStr.begin(), newStr.end(), newStr.begin(),::toupper);
        if(newStr == "TRUE" || newStr == "1"){
            return true;
        }
        else if(newStr == "FALSE" || newStr == "0"){
            return false;
        }
        else{
            throw std::invalid_argument("Invalid value for bool string");
        }
    }
    static Bool valueOf(bool b){
        std::unique_ptr<Bool> bVal(new Bool(b));
        return *(bVal->currState);
    }
    static Bool valueOf(const std::string s){
        std::unique_ptr<Bool> bVal(new Bool(s));
        return *(bVal->currState);
    }
    /*END METHODS*/
};
#endif //WRAPPERS_BOOL_H