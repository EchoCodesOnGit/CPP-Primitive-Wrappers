/*
 * This wrapper class was made to mimic the behavior of java-style wrapper classes. As of 12/21/24
 * it is still heavily a work-in-progress. It uses short to represent the values so the said values
 * are represented by at least 8 bytes(64 bits).
 *
 * @author Ethan Smith
 * @version 0.1
*/
#ifndef WRAPPERS_SHORT_H
#define WRAPPERS_SHORT_H
#include "../../functionality/class_necessities.h"
class Short{
    
private:
    short* value;
public:
    /*FIELDS*/
    static constexpr short BYTES = sizeof(short);
    static constexpr short MAX_VALUE = SHRT_MAX;
    static constexpr short MIN_VALUE = SHRT_MIN;
    static constexpr short SIZE = sizeof(short) * 8;
    //static Class<Short> TYPE; //need to figure out how to implement this, will probably have to make own Class class
    /*END FIELDS*/

    /*CONSTRUCTORS*/
    explicit Short(short value){
        this->value = new short(value);
    }


    explicit Short(const std::string& str) {
        try {
            this->value = new short(static_cast<short>(std::stoi(str)));
        } catch (const std::invalid_argument &iaExcept) {
            std::cerr << "Invalid argument - " << iaExcept.what() << '\n';
        } catch (const std::out_of_range &oorExcept) {
            std::cerr << "Out of range - " << oorExcept.what() << '\n';
        }
    }
    /*END CONSTRUCTORS*/

    /*METHODS*/

    /*
     * The following # section does the same thing in both functions but has different implementations
     * @since 0.1
     */
    auto byteValue() {
        #if __cplusplus < 201703L
                return static_cast<char>(*this->value);
        #elif __cplusplus >= 201703L
                return static_cast<std::byte>(*this->value);
        #endif
    }

    static int compare(short x, short y){
        return x < y ? -1 : x > y ? 1 : 0;
    }

    int compareTo(Short *anotherShort){
        return *anotherShort->value > *this->value ? 1 : *anotherShort->value < *this->value  ? -1 : 0;
    }

    static Short decode(const std::string& nm) {
        try {
            return *(new Short(nm));
        } catch (const std::invalid_argument& iaExcept) {
            std::cerr << "Invalid argument - " << iaExcept.what() << '\n';
            return *(new Short(0));
        } catch (const std::out_of_range& oorExcept) {
            std::cerr << "Out of range - " << oorExcept.what() << '\n';
            return *(new Short(0));
        }
    }

    double doubleValue(){
        return (double)*this->value;
    }

    float floatValue(){
        return (float)*this->value;
    }

    size_t hashCode(){
        return std::hash<short>()(*this->value);
    }

    static size_t hashCode(short hashItem){
        return std::hash<short>()(hashItem);
    }

    long longValue(){
        return (long)*this->value;
    }

    static short parseShort(const std::string& str){
        return (short)std::stoi(str);
    }

    static short parseShort(const std::string& str, short radix){
        return (short)std::stoi(str, nullptr, radix);
    }

    static short reverseBytes(short i){
        short result = 0;
        for (int j = 0; j < 4; ++j) {
            result |= (i & 0xFF) << (24 - (j * 8));
            i >>= 8;
        }
        return result;
    }


    short shortValue(){
        return (short)(*this->value);
    }

    static auto add(short a, short b){
        return a + b;
    }

    std::string toString(){
        return std::to_string(*this->value);
    }

    static std::string toString(short i){
        return std::to_string(i);
    }

    static unsigned int toUnsignedInt(short i){
        return (unsigned int)(i);
    }

    static unsigned long toUnsignedLong(short i){
        return (unsigned long)i;
    }

    static Short valueOf(short i){
        return *(new Short(i));
    }

    static Short valueOf(const std::string& str){
        return *(new Short(str));
    }

    static Short valueOf(const std::string& str, short radix) {
        if (radix < 2 || radix > 36) {
            throw std::invalid_argument("Radix must be between 2 and 36.");
        }

        const char digits[] = "0123456789abcdefghijklmnopqrstuvwxyz";
        bool isNegative = false;
        size_t startIdx = 0;

        if (str[0] == '-' && radix == 10) {
            isNegative = true;
            startIdx = 1;
        }

        unsigned short value = 0;

        for (size_t i = startIdx; i < str.length(); ++i) {
            char c = std::tolower(str[i]);
            short digit = -1;

            for (short j = 0; j < radix; ++j) {
                if (digits[j] == c) {
                    digit = j;
                    break;
                }
            }

            if (digit == -1) {
                throw std::invalid_argument("Invalid character for the specified radix.");
            }

            value = value * radix + digit;
        }

        if (isNegative) {
            return Short(-static_cast<short>(value));
        } else {
            return Short(static_cast<short>(value));
        }
    }


    /*
     * Works similar as to java.lang.Object.toString() in a way that you don't have to use a getter to obtain
     * the value(s) within the object when printing it out
     * @since 0.1
     */
    friend std::ostream& operator<<(std::ostream& os, const Short* shortObj) {
        if (shortObj != nullptr && shortObj->value != nullptr) {
            os << *(shortObj->value);
        } else {
            os << "NULL";
        }
        return os;
    }

    /*
     * Acts as the c++ equivalent of java's Object.equals() function when comparing objects
     * @since 0.1
     */
    bool operator==(const aptr anotherShort) const {
        if (this == anotherShort) {
            return true;
        }
        return *this->value == *anotherShort->value;
    }

    bool operator>(const aptr anotherShort) const {
        return *this->value > *anotherShort->value;
    }
    bool operator<(const aptr anotherShort) const {
        return *this->value < *anotherShort->value;
    }
    bool operator>=(const aptr anotherShort) const {
        return *this->value >= *anotherShort->value;
    }
    bool operator<=(const aptr anotherShort) const {
        *this->value <= *anotherShort->value;
    }

    /*DECONSTRUCTOR*/
    ~Short(){
        delete[] value;
    }
};
#endif //WRAPPERS_SHORT_H
