//
// Created by ebane on 12/28/2024.
//

#ifndef WRAPPERS_DOUBLE_H
#define WRAPPERS_DOUBLE_H
//
// Created by ebane on 12/27/2024.
//
#include "../../functionality/class_necessities.h"
class Double {
private:
    double *value;
public:
    /*FIELDS*/
    static constexpr double BYTES = sizeof(double);
    static constexpr double MAX_EXP = FLT_MAX_EXP;
    static constexpr double MAX_VALUE = FLT_MAX;
    static constexpr double MIN_EXP = FLT_MIN_EXP;
    static constexpr double MIN_NORMAL = FLT_MIN_NORMAL;
    static constexpr double MIN_VALUE = FLT_MIN;
    static constexpr double NaN = NAN;
    static constexpr double NEGATIVE_INFINITY = -INFINITY;
    static constexpr double POSITIVE_INFINITY = INFINITY;
    static constexpr double SIZE = sizeof(double) * 8;
    //static Class<double> TYPE; //need to figure out how to implement this, will probably have to make own Class class
    /*END FIELDS*/

    /*CONSTRUCTORS*/
    explicit Double(double value) {
        this->value = new double(value);
    }
    explicit Double(const std::string &str) {
        try {
            this->value = new double(static_cast<double>(std::stoi(str)));
        } catch (const std::invalid_argument &iaExcept) {
            std::cerr << "Invalid argument - " << iaExcept.what() << '\n';
        } catch (const std::out_of_range &oorExcept) {
            std::cerr << "Out of range - " << oorExcept.what() << '\n';
        }
    }
    /*END CONSTRUCTORS*/

    /*METHODS*/
    /*
     * The following # section does the same thing in both functions but has different implementations
     * @since 0.1
     */
    auto byteValue() {
#if __cplusplus < 201703L
        return static_cast<char>(*this->value);
#elif __cplusplus >= 201703L
        return static_cast<std::byte>(*this->value);
#endif
    }

    static int compare(double x, double y) {
        return x < y ? -1 : x > y ? 1 : 0;
    }

    int compareTo(Double *anotherDouble) {
        return *anotherDouble->value > *this->value ? 1 : *anotherDouble->value < *this->value ? -1 : 0;
    }

    double doubleValue() {
        return (double) *this->value;
    }

    size_t hashCode() {
        return std::hash<double>()(*this->value);
    }

    static size_t hashCode(double hashItem) {
        return std::hash<double>()(hashItem);
    }

    static long long doubleToLongBits(double value) {
        if (std::isnan(value)) {
            // Handle NaN conversion (normalize NaN if needed)
            value = std::numeric_limits<double>::quiet_NaN();
        }
        long long bits;
        std::memcpy(&bits, &value, sizeof(bits));
        return bits;
    }

    static long long doubleToRawLongBits(double value) {
        long long bits;
        std::memcpy(&bits, &value, sizeof(bits));
        return bits;
    }

    static double longBitsToDouble(long longBits) {
        double value;
        std::memcpy(&value, &longBits, sizeof(double));
        return value;
    }

    int intValue() {
        return static_cast<int>(*this->value);
    }

    static bool isFinite(double f) {
        if (std::isinf(f) || std::isnan(-f) || std::isnan(f)) {
            return false;
        }
        return true;
    }

    bool isInfinite() {
        if (std::isinf(*this->value) || std::isinf(-(*this->value))) {
            return true;
        }
        return false;
    }

    static bool isInfinite(double f) {
        if (std::isinf(f) || std::isinf(-(f))) {
            return true;
        }
        return false;
    }

    bool isNan() {
        if (std::isnan(*this->value) || std::isnan(-(*this->value))) {
            return true;
        }
        return false;
    }

    static bool isNan(double f) {
        if (std::isnan(f) || std::isnan(-(f))) {
            return true;
        }
        return false;
    }

    long longValue() {
        return (long) *this->value;
    }

    static double max(double a, double b) {
        return a > b ? a : b;
    }

    static double min(double a, double b) {
        return a < b ? a : b;
    }

    static double parseDouble(const std::string &str) {
        return (double)std::stoi(str);
    }

    short shortValue() {
        return (short)(*this->value);
    }

    static auto sum(double a, double b) {
        return a + b;
    }

    static std::string toHexString(double i) {
        std::stringstream ss;
        ss << std::hex << i;
        return ss.str();
    }

    std::string toString() {
        std::ostringstream os;
        os << std::fixed << std::setprecision(15) << *this->value;
        return os.str();
    }

    static std::string toString(double i) {
        std::ostringstream os;
        os << std::fixed << std::setprecision(15) << i;
        return os.str();
    }

    static std::optional<Double> valueOf(double i) {
        aptr doublePtr = new Double(static_cast<double>((i)));
        Double result = *doublePtr;
        delete doublePtr;
        return result;
    }

    static std::optional<Double> valueOf(const std::string &str) {
        aptr doublePtr = new Double(static_cast<double>(std::stoi(str)));
        std::optional<Double> result = *doublePtr;
        delete doublePtr;
        return result;
    }

    /*
     * Works similar as to java.lang.Object.toString() in a way that you don't have to use a getter to obtain
     * the value(s) within the object when printing it out
     * @since 0.1
     */
    friend std::ostream &operator<<(std::ostream &os, const Double *doubleObj) {
        if (doubleObj && doubleObj->value) {
            os << std::setprecision(15) << *doubleObj->value;
        } else {
            os << "NULL";
        }
        return os;
    }

    /*
     * Acts as the c++ equivalent of java's Object.equals() function when comparing objects
     * @since 0.1
     */
    bool operator==(const aptr anotherDouble) const {
        if (this == anotherDouble) {
            return true;
        }
        return *this->value == *anotherDouble->value;
    }

    bool operator>(const aptr anotherDouble) const {
        return *this->value > *anotherDouble->value;
    }

    bool operator<(const aptr anotherDouble) const {
        return *this->value < *anotherDouble->value;
    }

    bool operator>=(const aptr anotherDouble) const {
        return *this->value >= *anotherDouble->value;
    }

    bool operator<=(const aptr anotherDouble) const {
        *this->value <= *anotherDouble->value;
    }

    /*DECONSTRUCTOR*/
    ~Double() {
        delete[] value;
    }
};
#endif //WRAPPERS_DOUBLE_H
