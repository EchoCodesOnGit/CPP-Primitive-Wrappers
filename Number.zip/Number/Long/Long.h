//
// Created by ebane on 12/24/2024.
//

#ifndef WRAPPERS_LONG_H
#define WRAPPERS_LONG_H
/*
 * This wrapper class was made to mimic the behavior of java-style wrapper classes. As of 12/21/24
 * it is still heavily a work-in-progress. It uses long long to represent the values so the said values
 * are represented by at least 8 bytes(64 bits).
 *
 * @author Ethan Smith
 * @version 0.1
*/
#include "../../functionality/class_necessities.h"
class Long{
private:
    long long* value;
public:
    /*FIELDS*/
    static constexpr long long BYTES = sizeof(long long);
    static constexpr long long MAX_VALUE = LONG_LONG_MAX;
    static constexpr long long MIN_VALUE = LONG_LONG_MIN;
    static constexpr long long SIZE = sizeof(long long) * 8;
    //static Class<Long> TYPE; //need to figure out how to implement this, will probably have to make own Class class
    /*END FIELDS*/

    /*CONSTRUCTORS*/
    explicit Long(long long value){
        this->value = new long long(value);
    }


    explicit Long(const std::string& str) {
        try {
            this->value = new long long(std::stoi(str));
        } catch (const std::invalid_argument &iaExcept) {
            std::cerr << "Invalid argument - " << iaExcept.what() << '\n';
        } catch (const std::out_of_range &oorExcept) {
            std::cerr << "Out of range - " << oorExcept.what() << '\n';
        }
    }
    /*END CONSTRUCTORS*/

    /*METHODS*/
    /*
     * Returns the number of active bits in a given value
     * @since 0.1
     */
    static long long bitCount(long long i) {
        long long count = 0;
        while (i) {
            count += i & 1; //check if the least significant bit is 1
            i >>= 1;        //right shift the number
        }
        return count;
    }

    /*
     * The following # section does the same thing in both functions but has different implementations
     * @since 0.1
     */
    auto byteValue() {
        #if __cplusplus < 201703L
                return static_cast<char>(*this->value);
        #elif __cplusplus >= 201703L
                return static_cast<std::byte>(*this->value);
        #endif
    }

    static int compare(long long x, long long y){
        return x < y ? -1 : x > y ? 1 : 0;
    }

    int compareTo(Long *anotherLong){
        return *anotherLong->value > *this->value ? 1 : *anotherLong->value < *this->value  ? -1 : 0;
    }

    static int compareUnsigned(long long x, long long y){
        return (unsigned long long)(x < y) ? -1 : (unsigned long long)(x > y) ? 1 : 0;
    }

    static Long decode(const std::string& nm) {
        try {
            return *(new Long(nm));
        } catch (const std::invalid_argument& iaExcept) {
            std::cerr << "Invalid argument - " << iaExcept.what() << '\n';
            return *(new Long(0));
        } catch (const std::out_of_range& oorExcept) {
            std::cerr << "Out of range - " << oorExcept.what() << '\n';
            return *(new Long(0));
        }
    }

    static unsigned long long divideUnsigned(long long dividend, long long divisor){
        return (unsigned long long)(dividend / divisor);
    }

    double doubleValue(){
        return (double)*this->value;
    }

    float floatValue(){
        return (float)*this->value;
    }

    static Long getLong(const std::string& nm){
        const char* envVar = std::getenv(nm.c_str());
        if (envVar != nullptr) {
            try {
                return *(new Long(std::stoi(envVar)));
            } catch (const std::invalid_argument& e) {
                std::cerr << "Invalid argument: " << e.what() << std::endl;
            } catch (const std::out_of_range& e) {
                std::cerr << "Out of range: " << e.what() << std::endl;
            }
        } else {
            std::cerr << "Environment variable not found." << std::endl;
        }
        return *(new Long(0));
    }

    static long long getLong(const std::string& nm, long val) {
        const char *envVar = std::getenv(nm.c_str());
        if (envVar != nullptr) {
            try {
                return std::stoi(envVar);
            } catch (const std::invalid_argument &e) {
                std::cerr << "Invalid argument: " << e.what() << std::endl;
            } catch (const std::out_of_range &e) {
                std::cerr << "Out of range: " << e.what() << std::endl;
            }
        }
        return val;
    }

    static std::optional<Long> getLong(const std::string& nm, std::optional<Long> val = std::nullopt) {
        const char* envVar = std::getenv(nm.c_str());
        if (envVar != nullptr) {
            try {
                aptr longPtr = new Long(std::stoi(envVar));
                std::optional<Long> result = *longPtr;
                delete longPtr;
                return result;
            } catch (const std::invalid_argument& e) {
                std::cerr << "Invalid argument: " << e.what() << std::endl;
            } catch (const std::out_of_range& e) {
                std::cerr << "Out of range: " << e.what() << std::endl;
            }
        }
        return val;
    }

    size_t hashCode(){
        return std::hash<long long>()(*this->value);
    }

    static size_t hashCode(long long hashItem){
        return std::hash<long long>()(hashItem);
    }

    static long long highestOneBit(long long i){
        if (i == 0) return 0;
        i |= (i >> 1);  // Step 1
        i |= (i >> 2);  // Step 2
        i |= (i >> 4);  // Step 3
        i |= (i >> 8);  // Step 4
        i |= (i >> 16); // Step 5
        return i - (i >> 1);
    }

    long long longValue(){
        return (long)*this->value;
    }

    static long long lowestOneBit(long long i){
        return i & -i;
    }

    static long long max(long long a, long long b){
        return a > b ? a : b;
    }

    static long long min(long long a, long long b){
        return a < b ? a : b;
    }

    static long long numberOfLeadingZeros(long long i){
        if (i == 0) return 32;
        long count = 0;
        for (long shift = 31; shift >= 0; --shift) {
            if ((i >> shift) & 1) break;
            count++;
        }
        return count;
    }

    static long long numberOfTrailingZeros(long long i){
        if (i == 0) return 32;
        long long count = 0;
        while (i > 0 && (i & 1) == 0) {
            i >>= 1;
            count++;
        }
        return count;
    }

    static long long parseLong(const std::string& str){
        return (long long)std::stoi(str);
    }

    static long long parseLong(const std::string& str, long long radix){
        return static_cast<long long>(std::stoi(str, nullptr, static_cast<int>(radix)));
    }

    static unsigned long long parseUnsignedInt(const std::string& str){
        return (unsigned long long)std::stoi(str);
    }

    static unsigned long long parseUnsignedInt(const std::string& str, long long radix){
        return (unsigned long long)std::stoi(str, nullptr, static_cast<int>(radix));
    }

    static unsigned long long remainderUnsigned(long long dividend, long long divisor){
        return (unsigned long long)(dividend % divisor);
    }

    static long long reverse(long long i) {
        long long result = 0;
        for (int j = 0; j < 32; ++j) {
            if (i & (1 << j)) {
                result |= (1 << (31 - j));
            }
        }
        return result;
    }

    static long long reverseBytes(long long i){
        long long result = 0;
        for (int j = 0; j < 4; ++j) {
            result |= (i & 0xFF) << (24 - (j * 8));
            i >>= 8;
        }
        return result;
    }

    static long long rotateLeft(long long i, long long distance) {
        const long long BIT_SIZE = 32;
        distance %= BIT_SIZE;
        return (i << distance) | (i >> (BIT_SIZE - distance));
    }

    static long long rotateRight(long long i, long long distance){
        const long long BIT_SIZE = 32;
        distance %= BIT_SIZE;
        return (i >> distance) | (i << (BIT_SIZE - distance));
    }

    short shortValue(){
        return (short)(*this->value);
    }

    static long long signum(long long x) {
        return (x > 0) - (x < 0);
    }

    static auto add(long long a, long long b){
        return a + b;
    }

    static std::string toBinaryString(long long i){
        return std::bitset<SIZE>(i).to_string();
    }

    static std::string toHexString(long long i){
        std::stringstream ss;
        ss << std::hex << i;
        return ss.str();
    }

    static std::string toOctalString(long long i){
        std::stringstream ss;
        ss << std::oct << i;
        return ss.str();
    }

    std::string toString(){
        return std::to_string(*this->value);
    }

    static std::string toString(long long i){
        return std::to_string(i);
    }

    static std::string toString(long long i, long long radix){
        if (radix < 2 || radix > 36) {
            throw std::invalid_argument("Radix must be between 2 and 36.");
        }

        const char digits[] = "0123456789abcdefghijklmnopqrstuvwxyz";
        bool isNegative = i < 0;
        unsigned long long value = isNegative ? -i : i;
        std::string result;
        do {
            result = digits[value % radix] + result;
            value /= radix;
        } while (value > 0);
        if (isNegative && radix == 10) {
            result = '-' + result;
        }
        return result;
    }

    static unsigned long long toUnsignedLong(long long i){
        return (unsigned long long)(i);
    }

    static std::string toUnsignedString(long long i){
        return std::to_string((unsigned long long)i);
    }

    static std::string toUnsignedString(long long i, long long radix){
        if (radix < 2 || radix > 36) {
            throw std::invalid_argument("Radix must be between 2 and 36.");
        }
        const char digits[] = "0123456789abcdefghijklmnopqrstuvwxyz";
        auto value = static_cast<unsigned long long>(i);  // Treat the number as unsigned
        std::string result;
        do {
            result = digits[value % radix] + result;
            value /= radix;
        } while (value > 0);
        return result;
    }

    static Long valueOf(long long i){
        return *(new Long(i));
    }

    static Long valueOf(const std::string& str){
        return *(new Long(str));
    }

    static Long valueOf(const std::string& str, long long radix) {
        if (radix < 2 || radix > 36) {
            throw std::invalid_argument("Radix must be between 2 and 36.");
        }

        const char digits[] = "0123456789abcdefghijklmnopqrstuvwxyz";
        bool isNegative = false;
        size_t startIdx = 0;

        if (str[0] == '-' && radix == 10) {
            isNegative = true;
            startIdx = 1;
        }

        unsigned long long value = 0;

        for (size_t i = startIdx; i < str.length(); ++i) {
            char c = std::tolower(str[i]);
            long long digit = -1;

            for (long long j = 0; j < radix; ++j) {
                if (digits[j] == c) {
                    digit = j;
                    break;
                }
            }

            if (digit == -1) {
                throw std::invalid_argument("Invalid character for the specified radix.");
            }

            value = value * radix + digit;
        }

        if (isNegative) {
            return Long(-static_cast<long long>(value));
        } else {
            return Long(static_cast<long long>(value));
        }
    }


    /*
     * Works similar as to java.lang.Object.toString() in a way that you don't have to use a getter to obtain
     * the value(s) within the object when printing it out
     * @since 0.1
     */
    friend std::ostream& operator<<(std::ostream& os, const Long* longObj) {
        if (longObj != nullptr && longObj->value != nullptr) {
            os << *(longObj->value);
        } else {
            os << "NULL";
        }
        return os;
    }

    /*
     * Acts as the c++ equivalent of java's Object.equals() function when comparing objects
     * @since 0.1
     */
    bool operator==(const auto* anotherLong) const {
        if (this == anotherLong) {
            return true;
        }
        return *this->value == *anotherLong->value;
    }
    bool operator>(const aptr anotherLong) const {
        return *this->value > *anotherLong->value;
    }
    bool operator<(const aptr anotherLong) const {
        return *this->value < *anotherLong->value;
    }
    bool operator>=(const aptr anotherLong) const {
        return *this->value >= *anotherLong->value;
    }
    bool operator<=(const aptr anotherLong) const {
        *this->value <= *anotherLong->value;
    }
    /*DECONSTRUCTOR*/
    ~Long(){
        delete[] value;
    }
};
#endif //WRAPPERS_LONG_H
