//
// Created by ebane on 12/27/2024.
//
#include "../../functionality/class_necessities.h"
#ifndef WRAPPERS_FLOAT_H
#define WRAPPERS_FLOAT_H
class Float {
private:
    float* value;
public:
    /*FIELDS*/
    static constexpr float BYTES = sizeof(float);
    static constexpr float MAX_EXP = FLT_MAX_EXP;
    static constexpr float MAX_VALUE = FLT_MAX;
    static constexpr float MIN_EXP = FLT_MIN_EXP;
    static constexpr float MIN_NORMAL = FLT_MIN_NORMAL;
    static constexpr float MIN_VALUE = FLT_MIN;
    static constexpr float NaN = NAN;
    static constexpr float NEGATIVE_INFINITY = -INFINITY;
    static constexpr float POSITIVE_INFINITY = INFINITY;
    static constexpr float SIZE = sizeof(float) * 8;
    //static Class<float> TYPE; //need to figure out how to implement this, will probably have to make own Class class
    /*END FIELDS*/

    /*CONSTRUCTORS*/
    explicit Float(float value) {
        this->value = new float(value);
    }

    explicit Float(double value) {
        this->value = new float(static_cast<float>(value));
    }

    explicit Float(const std::string& str) {
        try {
            this->value = new float(static_cast<float>(std::stoi(str)));
        } catch (const std::invalid_argument &iaExcept) {
            std::cerr << "Invalid argument - " << iaExcept.what() << '\n';
        } catch (const std::out_of_range &oorExcept) {
            std::cerr << "Out of range - " << oorExcept.what() << '\n';
        }
    }
    /*END CONSTRUCTORS*/

    /*METHODS*/
    /*
     * The following # section does the same thing in both functions but has different implementations
     * @since 0.1
     */
    auto byteValue() {
        #if __cplusplus < 201703L
                return static_cast<char>(*this->value);
        #elif __cplusplus >= 201703L
                return static_cast<std::byte>(*this->value);
        #endif
    }

    static int compare(float x, float y){
        return x < y ? -1 : x > y ? 1 : 0;
    }

    int compareTo(Float *anotherFloat){
        return *anotherFloat->value > *this->value ? 1 : *anotherFloat->value < *this->value  ? -1 : 0;
    }

    double doubleValue(){
        return (double)*this->value;
    }

    static uint32_t floatToIntBits(float value){
        if (std::isinf(value)) {
            return value > 0 ? 0x7f800000 : 0xff800000;
        }
        if (std::isnan(value)) {
            return 0x7fc00000;
        }
        int32_t intBits;
        std::memcpy(&intBits, &value, sizeof(float));
        return intBits;
    }

    static int32_t floatToRawIntBits(float value){
        int32_t intBits;
        std::memcpy(&intBits, &value, sizeof(float));
        return intBits;
    }

    size_t hashCode(){
        return std::hash<float>()(*this->value);
    }

    static size_t hashCode(float hashItem){
        return std::hash<float>()(hashItem);
    }

    float floatValue(){
        return *this->value;
    }

    static float intBitsToFloat(int32_t intBits){
        float value;
        std::memcpy(&value, &intBits, sizeof(float));
        return value;
    }

    int intValue(){
        return static_cast<int>(*this->value);
    }

    static bool isFinite(float f){
        if(std::isinf(f) || std::isnan(-f) || std::isnan(f)){
            return false;
        }
        return true;
    }

    bool isInfinite(){
        if(std::isinf(*this->value) || std::isinf(-(*this->value))){
            return true;
        }
        return false;
    }

    static bool isInfinite(float f){
        if(std::isinf(f) || std::isinf(-(f))){
            return true;
        }
        return false;
    }

    bool isNan(){
        if(std::isnan(*this->value) || std::isnan(-(*this->value))){
            return true;
        }
        return false;
    }

    static bool isNan(float f){
        if(std::isnan(f) || std::isnan(-(f))){
            return true;
        }
        return false;
    }

    long longValue(){
        return (long)*this->value;
    }

    static float max(float a, float b){
        return a > b ? a : b;
    }

    static float min(float a, float b){
        return a < b ? a : b;
    }

    static float parseFloat(const std::string& str){
        return (float)std::stoi(str);
    }

    short shortValue(){
        return (short)(*this->value);
    }

    static auto sum(float a, float b){
        return a + b;
    }

    static std::string toHexString(float i){
        std::stringstream ss;
        ss << std::hex << i;
        return ss.str();
    }

    std::string toString(){
        std::ostringstream os;
        os << std::fixed << std::setprecision(6) << *this->value;
        return os.str();
    }

    static std::string toString(float i){
        std::ostringstream os;
        os << std::fixed << std::setprecision(6) << i;
        return os.str();
    }

    static std::optional<Float> valueOf(float i){
        aptr floatPtr = new Float(static_cast<float>((i)));
        Float result = *floatPtr;
        delete floatPtr;
        return result;
    }

    static std::optional<Float> valueOf(const std::string& str){
        aptr floatPtr = new Float(static_cast<float>(std::stoi(str)));
        std::optional<Float> result = *floatPtr;
        delete floatPtr;
        return result;
    }

    /*
     * Works similar as to java.lang.Object.toString() in a way that you don't have to use a getter to obtain
     * the value(s) within the object when prfloating it out
     * @since 0.1
     */
    friend std::ostream& operator<<(std::ostream& os, const Float* floatObj) {
        if (floatObj && floatObj->value) {
            os << std::setprecision(6) << *floatObj->value;
        } else {
            os << "NULL";
        }
        return os;
    }

    /*
     * Acts as the c++ equivalent of java's Object.equals() function when comparing objects
     * @since 0.1
     */
    bool operator==(const aptr anotherFloat) const {
        if (this == anotherFloat) {
            return true;
        }
        return *this->value == *anotherFloat->value;
    }

    bool operator>(const aptr anotherFloat) const {
        return *this->value > *anotherFloat->value;
    }
    bool operator<(const aptr anotherFloat) const {
        return *this->value < *anotherFloat->value;
    }
    bool operator>=(const aptr anotherFloat) const {
        return *this->value >= *anotherFloat->value;
    }
    bool operator<=(const aptr anotherFloat) const {
        *this->value <= *anotherFloat->value;
    }

    /*DECONSTRUCTOR*/
    ~Float(){
        delete[] value;
    }
};
#endif //WRAPPERS_FLOAT_H
