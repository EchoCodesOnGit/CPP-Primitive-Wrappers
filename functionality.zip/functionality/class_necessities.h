//
// Created by ebane on 12/24/2024.
//

#ifndef WRAPPERS_CLASS_NECESSITIES_H
#define WRAPPERS_CLASS_NECESSITIES_H
#include <iostream>
#include <cstdint>
#include <cstring>
#include <string>
#include <cstddef>
#include <optional>
#include <cmath>
#include <bitset>
#include <sstream>
#include <climits>
#include <memory>
#include <vector>
#include <iomanip>
#include <bitset>
#include <limits>
#include <cfloat>
#include <sstream>
#include <algorithm>
#include <cstdlib>
#include <uni
#define aptr auto* //auto pointer

/*DEFINING UNDEFINED "TRANSLATIONS" FROM JAVA*/
#define FLT_MIN_NORMAL 1.1754943508223e-38
#define U_UNDEFINED -1
#define U_MAX_CODE_POINT 0x10FFFF
#define U_MAX_HIGH_SURROGATE '0xDBFF'
#define U_MAX_LOW_SURROGATE '0xDFFF'
#define U_MAX_RADIX 36
#define U_MIN_RADIX 2

namespace charConverter {
    static int toInt(char c){
        return c - '0';
    }
    static char toChar(int i){
        return (char)i;
    }
}

#endif //WRAPPERS_CLASS_NECESSITIES_H
