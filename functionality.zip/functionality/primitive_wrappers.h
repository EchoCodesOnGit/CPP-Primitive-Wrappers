//
// Created by ebane on 12/24/2024.
//

#ifndef WRAPPERS_PRIMITIVE_WRAPPERS_H
#define WRAPPERS_PRIMITIVE_WRAPPERS_H
#include "../Number/Byte/Byte.h"
#include "../Number/Integer/Integer.h"
#include "../Number/Long/Long.h"
#include "../Number/Short/Short.h"
#include "../Number/Float/Float.h"
#include "../Number/Double/Double.h"
#endif //WRAPPERS_PRIMITIVE_WRAPPERS_H
